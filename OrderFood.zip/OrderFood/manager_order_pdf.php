<?php
session_start();
require_once('tcpdf/examples/lang/eng.php');
require_once('tcpdf/tcpdf.php');
require_once('fonts/msungstdlight.php');
 
include 'connect.php';


// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
// ---------------------------------------------------------
 
// set font
//$pdf->SetFont('arialunicid0','',20);
//取消header
$pdf->SetFont('msungstdlight','',16);
$pdf->setPrintHeader(false);
//取消footer
$pdf->setPrintFooter(false);
// add a page
$pdf->AddPage();

$o_id=0;
if(isset($_GET['res'])){
	$res=$_GET['res'];
}

$query="SELECT DISTINCT o_id_n FROM order_detail WHERE res_name='$res'";
$result=mysqli_query($conn,$query);

$html="<html><head><link rel='stylesheet' type='text/css' href='css/all.css'></head><body><table><tr><td>訂單編號</td><td>訂購者</td><td>狀態</td><td>訂購時間</td></tr>";
while ($row=mysqli_fetch_row($result)) {
	$o_query="SELECT * FROM orders WHERE o_id_n='$row[0]'";
	//echo $o_query;
	$o_result=mysqli_query($conn,$o_query);
	while ($o_row=mysqli_fetch_row($o_result)) {
		$html=$html."<tr><td>$o_row[4]</td><td>$o_row[1]</td><td>$o_row[3]</td><td>$o_row[2]</td></tr>";
	}
}
//echo $html;
$pdf->writeHTML($html, true, false, true, false, '');
/*$pdf->Write(10,'第一列');
$pdf->Ln();
$pdf->SetFontSize(24);
$pdf->Write(10,'第二列');
$pdf->Ln();
$pdf->SetFontSize(28);
$pdf->Write(10,'第三列');*/
$pdf->lastPage();
ob_end_clean();
$pdf->Output('test.pdf','I');
 
 
// ---------------------------------------------------------
 
//Close and output PDF document

 
//============================================================+
// END OF FILE                                                
//============================================================+
?>