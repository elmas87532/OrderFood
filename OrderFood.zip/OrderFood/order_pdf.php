<?php
session_start();
require_once('tcpdf/examples/lang/eng.php');
require_once('tcpdf/tcpdf.php');
require_once('fonts/msungstdlight.php');
 
include 'connect.php';


// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
// ---------------------------------------------------------
 
// set font
//$pdf->SetFont('arialunicid0','',20);
//取消header
$pdf->SetFont('msungstdlight','',16);
$pdf->setPrintHeader(false);
//取消footer
$pdf->setPrintFooter(false);
// add a page
$pdf->AddPage();

$o_id=0;
if(isset($_GET['o_id'])){
	$o_id=$_GET['o_id'];
}
if (isset($_SESSION['getway'])) {
	$getway=$_SESSION['getway'];
}
$query="SELECT * FROM order_detail WHERE o_id=$o_id";
$result=mysqli_query($conn,$query);
$rows=mysqli_num_rows($result);
$sum=0;
$html="<html><head><link rel='stylesheet' type='text/css' href='css/all.css'></head><body><table><tr><td>編號</td><td>商品</td><td>餐廳</td><td>數量</td><td>價格</td></tr>";
for ($i=0; $i < $rows; $i++) {
	$vi=$i+1;
	$row=mysqli_fetch_row($result); 

	switch ($row[2]) {
		case 'hauchang':
			$u_res="後倉";
			break;
		case 'db':
			$u_res="低逼";
			break;
		case 'chuanting':
			$u_res="穿停";
			break;
		case 'res1':
			$u_res="res1";
			break;
		case 'res2':
			$u_res="res2";
			break;
		case 'res3':
			$u_res="res3";
			break;
		case 'res4':
			$u_res="res4";
			break;
		case 'res5':
			$u_res="res5";
			break;
		
		default:
			# code...
			break;
		}
	
	$sum+=$row[4];
	$html=$html."<tr><td>$vi</td><td>$row[1]</td><td>$u_res</td><td>$row[3]</td><td>$row[4]</td><td></td></tr>";
}
$html=$html."</table>商品總額：$sum<br/>取餐方式：$getway</body></html>";
//echo $html;
$pdf->writeHTML($html, true, false, true, false, '');
/*$pdf->Write(10,'第一列');
$pdf->Ln();
$pdf->SetFontSize(24);
$pdf->Write(10,'第二列');
$pdf->Ln();
$pdf->SetFontSize(28);
$pdf->Write(10,'第三列');*/
$pdf->lastPage();
ob_end_clean();
$pdf->Output('test.pdf','I');
 
 
// ---------------------------------------------------------
 
//Close and output PDF document

 
//============================================================+
// END OF FILE                                                
//============================================================+
?>