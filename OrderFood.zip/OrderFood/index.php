<?php
session_start();


function mobile_check(){
$mobile_browser = false;
$user_agent = $_SERVER['HTTP_USER_AGENT'];
$accept = $_SERVER['HTTP_ACCEPT'];
if(preg_match('/(acs|alav|alca|amoi|audi|aste|avan|benq|bird|blac|blaz|brew|cell|cldc|cmd-)/i',$user_agent)){
$mobile_browser = true;
}elseif(preg_match('/(dang|doco|erics|hipt|inno|ipaq|java|jigs|kddi|keji|leno|lg-c|lg-d|lg-g|lge-)/i',$user_agent)){
$mobile_browser = true;
}elseif(preg_match('/(maui|maxo|midp|mits|mmef|mobi|mot-|moto|mwbp|nec-|newt|noki|opwv)/i',$user_agent)){
$mobile_browser = true;
}elseif(preg_match('/(palm|pana|pant|pdxg|phil|play|pluc|port|prox|qtek|qwap|sage|sams|sany)/i',$user_agent)){
$mobile_browser = true;
}elseif(preg_match('/(sch-|sec-|send|seri|sgh-|shar|sie-|siem|smal|smar|sony|sph-|symb|t-mo)/i',$user_agent)){
$mobile_browser = true;
}elseif(preg_match('/(teli|tim-|tosh|tsm-|upg1|upsi|vk-v|voda|w3cs|wap-|wapa|wapi)/i',$user_agent)){
$mobile_browser = true;
}elseif(preg_match('/(wapp|wapr|webc|winw|winw|xda|xda-)/i',$user_agent)){
$mobile_browser = true;
}elseif(preg_match('/(up.browser|up.link|windowssce|iemobile|mini|mmp)/i',$user_agent)){
$mobile_browser = true;
}elseif(preg_match('/(symbian|midp|wap|phone|pocket|mobile|pda|psp)/i',$user_agent)){
$mobile_browser = true;
}
if((strpos($accept,'text/vnd.wap.wml')>0)||(strpos($accept,'application/vnd.wap.xhtml+xml')>0)){
$mobile_browser = true;
}
return $mobile_browser;

}

$menu=""; 
$login="";
$sign="";

if(mobile_check()){

//header('Location: mobile_menu.php');
$menu="mobile_menu";
$login="mobile_login";
$sign="mobile_sign";

}else{

//echo "PC";;
	$menu="menu";
	$login="login";
	$sign="sign";

}


$u_id="";
if(isset($_SESSION['u_id'])){
	$u_id=$_SESSION['u_id'];
}

if(isset($_POST['logined'])){

	$u_id=$_POST['u_id'];
	$u_pw=$_POST['u_pw'];

	//echo "logined";
	$query="SELECT * FROM user WHERE u_id='$u_id'";
	$m_query="SELECT * FROM manager WHERE m_id='$u_id'";
	//echo $query;
	$result=mysqli_query($conn,$query);
	$m_result=mysqli_query($conn,$m_query);


	$row=mysqli_fetch_row($result);
	$m_row=mysqli_fetch_row($m_result);


	if($row[0]!=null && $row[1]!=null && $u_id==$row[0] && $u_pw==$row[1]){
		$_SESSION['u_id']=$row[0];
	}elseif ($m_row[0]!=null && $m_row[1]!=null && $u_id==$m_row[0] && $u_pw==$m_row[1]) {
		header("Location:manager_menu.php?res=$m_row[2]");
	}else{
		echo "<script>alert('帳號密碼有誤，請重新登入')</script>";
	}
	

}

$id_type="";
if (isset($_SESSION['id_type'])) {
	$id_type=$_SESSION['id_type'];
}


echo <<<_END

<html>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Let's Ordering</title>
	<link rel="stylesheet" type="text/css" href="css/index.css">
</head>
<body>
<div class="index_wrap">
	<div class="index_header">
		<h1>歡‧迎‧光‧臨‧訂‧餐‧細‧桶</h1>
	</div>

	<div class="index_block">
		<img src="img/index_logo.png">
	</div>
	<div class="index_block">
		<a href="$menu.php?res=chuanting"><img src="img/chuanting.png"></a>
	</div>
	<div class="index_block">
		<img src="img/index_logo.png">
	</div>
	<div class="index_block">
		<a href="$menu.php?res=hauchang"><img src="img/hauchang.png"></a>
	</div>
	<div class="index_block">
		<a href="$menu.php?res=db"><img src="img/db.png"></a>
	</div>
	<div class="index_block">
		<img src="img/index_logo.png">
	</div>
	<div class="index_block">
		<a href="$menu.php?res=res1"><img src="img/res1.png"></a>
	</div>
	<div class="index_block">
		<img src="img/index_logo.png">
	</div>
	<div class="index_block">
		<img src="img/index_logo.png">
	</div>
	<div class="index_block">
		<a href="$menu.php?res=res2"><img src="img/res2.png"></a>
	</div>
	<div class="index_block">
		<img src="img/index_logo.png">
	</div>
	<div class="index_block">
		<a href="$menu.php?res=res3"><img src="img/res3.png"></a>
	</div>
	<div class="index_block">
		<a href="$menu.php?res=res4"><img src="img/res4.png"></a>
	</div>
	<div class="index_block">
		<img src="img/index_logo.png">
	</div>
	<div class="index_block">
		<a href="$menu.php?res=res5"><img src="img/res5.png"></a>
	</div>
	<div class="index_block">
		<img src="img/index_logo.png">
	</div><br/>
	<div class="index_button">
		<a class="menu" href="$login.php">會員登入</a>
		<a class="menu" href="$sign.php">註冊帳號</a>
	</div>
	

</div>
	
</body>
</html>
</html>

_END;

?>

