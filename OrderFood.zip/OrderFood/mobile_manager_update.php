<?php
include("connect.php");
session_start();

if (isset($_SESSION['res'])) {
	$res=$_SESSION['res'];
}

$up_pro_id=0;
$unup_pro_name="";
$unup_pro_price=0;
$unup_type_name="";
$unup_pro_path="";

if(isset($_GET['up_pro_id'])){
	$up_pro_id=$_GET['up_pro_id'];
	$query="SELECT * FROM product WHERE pro_id='$up_pro_id'";
	$result=mysqli_query($conn,$query);
	$row=mysqli_fetch_row($result);
	$up_pro_id=$row[0];
	$unup_pro_name=$row[1];
	$unup_pro_price=$row[2];
	$unup_type_name=$row[4];
	$unup_pro_path=$row[5];
}

if(isset($_GET['logout'])){
	unset($_SESSION['res']);
}

echo <<<_END
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Let's Ordering</title>
	<link rel="stylesheet" type="text/css" href="css/mobile.css">
</head>
<body>
	<div class="wrap">
		<div class="header">
		<a href="index.php"><img src="img/LOGO.png"></a>
		<div class="ezlogin">
_END;
			$query="SELECT * FROM manager WHERE res_name='$res'";
			$result=mysqli_query($conn,$query);
			$row=mysqli_fetch_row($result);
			echo "歡迎，$row[2]!&nbsp;&nbsp;";
			echo "<a href='mobile_menu.php?logout=true'>登出</a>";
echo <<<_END
		</div>
		</div>
		
		<div class="nav">
			<ul>
				<li><a href="mobile_manager_menu.php?res=res2">菜單管理</a></li>
				<li><a href="mobile_manager_menu.php?res=res3">訂單管理</a></li>
			</ul>
		</div>
		<div class="maincontent">
			<form enctype="multipart/form-data" method="post" action="mobile_manager_update.php">
				商品圖片：<br />
				<input type="file" name="filename" />
				<input type="hidden" name="up_pro_id" value="$up_pro_id"/>
				<input type="hidden" name="unup_pro_name" value="$unup_pro_name"/>
				<input type="hidden" name="unup_pro_price" value="$unup_pro_price"/>
				<input type="hidden" name="unup_type_name" value="$unup_type_name"/>
				<input type="hidden" name="unup_pro_path" value="$unup_pro_path"/>
				<input type="hidden" name="original" value="true"/>
	  			<input type="submit" value="上傳"/>
	  		</form>
_END;

if (isset($_POST['original'])) {
	$up_pro_id=$_POST['up_pro_id'];
	$unup_pro_name=$_POST['unup_pro_name'];
	$unup_pro_price=$_POST['unup_type_name'];
	$unup_type_name=$_POST['unup_pro_price'];
	$unup_pro_path=$_POST['unup_pro_path'];
}

$ext="";
if($_FILES){
	$name=$_FILES['filename']['name'];

	switch ($_FILES['filename']['type']) {
		case 'image/jpeg': $ext='jpg';break;
		case 'image/gif': $ext='gif';break;
		case 'image/png': $ext='png';break;
		case 'image/tiff': $ext='tif';break;
		default: $ext=''; break;
	}
	
	$n="";
	if($ext!=null){
		$n="menuinfo/$res/tmp.$ext";
		move_uploaded_file($_FILES['filename']['tmp_name'], $n);
		echo "<br/><img src='$n' width='300px' height='300px' />";
		//echo $ext;
	}

}else{
	echo "<img src='$unup_pro_path' width='300px' height='300px' />";
}

echo <<<_END
			<form action="mobile_manager_menu.php" method="post">
				商品名稱：<input type="text" name="up_pro_name" value="$unup_pro_name"/><br />
				商品類型：<input type="text" name="up_type_name" value="$unup_type_name"/><br />
				商品價格：<input type="text" name="up_pro_price" value="$unup_pro_price"/><br />
				<input type="hidden" name="up_pro_id" value="$up_pro_id"/>
				<input type='hidden' name='unup_pro_path' value='$unup_pro_path'/>
_END;

if ($ext!=null) {
	echo "<input type='hidden' name='have_ext' value='true'/>";
	echo "<input type='hidden' name='up_pro_ext' value='$ext'/>";
}
			
echo <<<_END
				<input type="submit" value="儲存" />
			</form>
		</div>
	</div>
</body>
</html>
_END;
?>