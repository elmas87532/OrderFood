<?php
include 'connect.php';
session_start();

if (isset($_SESSION['u_id'])) {
	$u_id=$_SESSION['u_id'];
	if (!isset($_SESSION['items']) && !isset($_SESSION['num'])) {
		$_SESSION['items']=array();
		$_SESSION['num']=array();
	}

	if(isset($_POST['num']) && isset($_POST['pro_id'])){
		$id=$_POST['pro_id'];
		$num=$_POST['num'];
		//echo $_POST['num'];
		if((int)$_POST['num']<0){
			echo "<script>alert('數量有誤！')</script>";
			$num=0;
			//header("Location:menu.php");
		}else if((int)$_POST['num']>100){
			echo "<script>alert('單項不可超過100份')</script>";
			$num=0;
		}
		if(is_numeric(array_search($id,$_SESSION['items']))){
			//echo "yes";
			$index=array_search($id,$_SESSION['items']);
			$_SESSION['num'][$index]=$_SESSION['num'][$index]+$num;
		}else{
			//echo "no";
			
			if($num>0){
				array_push($_SESSION['items'], $id);
				array_push($_SESSION['num'], $num);
			}
			
		}
	}

	if(isset($_POST['del_item'])){
		$del=$_POST['del_item'];
		unset($_SESSION['items'][$del]);
		$_SESSION['items']=array_values($_SESSION['items']);
		unset($_SESSION['num'][$del]);
		$_SESSION['num']=array_values($_SESSION['num']);
	}

	if(isset($_POST['diminish'])){
		$d_index=$_POST['d_i'];
		$_SESSION['num'][$d_index]=$_SESSION['num'][$d_index]-1;
		if($_SESSION['num'][$d_index]<=0){
			$_SESSION['num'][$d_index]=$_SESSION['num'][$d_index]+1;
		}
	}

	if(isset($_POST['add'])){
		$a_index=$_POST['a_i'];
		$_SESSION['num'][$a_index]=$_SESSION['num'][$a_index]+1;
	}

	$tmp_item=$_SESSION['items'];
	$tmp_num=$_SESSION['num'];

echo <<<_END

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Let's Ordering</title>
	<link rel="stylesheet" type="text/css" href="css/all.css">
</head>
<body>
	<div class="wrap">
		<div class="header">
		<a href="index.php"><img src="img/LOGO.png"></a>
		<div class="ezlogin">
_END;
			$query="SELECT * FROM user WHERE u_id='$u_id'";
			$result=mysqli_query($conn,$query);
			$row=mysqli_fetch_row($result);
			echo "安安，$row[2]!&nbsp;&nbsp;";
			echo "<a href='select_order.php'>訂單查詢</a>&nbsp;&nbsp;";
			echo "<a href='menu.php?logout=true'>登出</a>";
echo <<<_END
		</div>
		</div>
		<div class="operation">
			<h1>Menu</h1>
		</div>
		<div class="sidebar">
			<ul class="sidebars">
				<li>商店總覽</li>
				<li><a href="menu.php?res=hauchang">後倉</a></li>
				<li><a href="menu.php?res=db">低逼</a></li>
				<li><a href="menu.php?res=chuanting">穿停</a></li>
				<li><a href="menu.php?res=res1">res1</a></li>
				<li><a href="menu.php?res=res2">res2</a></li>
				<li><a href="menu.php?res=res3">res3</a></li>
				<li><a href="menu.php?res=res4">res4</a></li>
				<li><a href="menu.php?res=res5">res5</a></li>
			</ul>
		</div>
		<div class="maincontent">
_END;
echo "<table><tr><th>編號</th><th>商品名稱</th><th>餐廳</th><th>數量</th><th>價格</th><th>刪除</th></tr>";
for ($i=0; $i<count($_SESSION['items']) ; $i++) {
	$query="SELECT * FROM product WHERE pro_id='$tmp_item[$i]'";
	$result=mysqli_query($conn,$query);
	$row=mysqli_fetch_row($result); 
	$total_price=$row[2]*$tmp_num[$i];
	$vi=$i+1;
	switch ($row[3]) {
		case 'hauchang':
			$u_res="後倉";
			break;
		case 'db':
			$u_res="低逼";
			break;
		case 'chuanting':
			$u_res="穿停";
			break;
		case 'res1':
			$u_res="res1";
			break;
		case 'res2':
			$u_res="res2";
			break;
		case 'res3':
			$u_res="res3";
			break;
		case 'res4':
			$u_res="res4";
			break;
		case 'res5':
			$u_res="res5";
			break;
		
		default:
			# code...
			break;
	}
	echo "<tr><td>$vi</td><td>$row[1]</td><td>$u_res</td>
	<td><form action='cart.php' method='post'><input type='hidden' name='add' value='true'/><input type='hidden' name='a_i' value='$i'/><input type='submit' value='＋'/></form>$tmp_num[$i]<form action='cart.php' method='post'><input type='hidden' name='diminish' value='true'/><input type='hidden' name='d_i' value='$i'/><input type='submit' value='－'/></form></td><td>$total_price</td>
	</form><form action='cart.php' method='post'><td><input type='hidden' name='del_item' value='$i'/><input type='submit' value='刪除'/></td></form></tr>";
}
echo "</table>";

echo <<<_END
		<div class='cart_next'>
			<a href="menu.php">回菜單</a><a href="check_address.php">下一步</a>
		</div>
_END;

}else {
echo <<<_END
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Let's Ordering</title>
	<link rel="stylesheet" type="text/css" href="css/lns.css">
</head>
<body>
	<div class="wrap">
		<div class="header">
		<a href="index.php"><img src="img/LOGO.png"></a>
		</div>
		<div class="operation">
			<h1>Login</h1>
		</div>
		<div class="sidebar">
			<ul class="sidebars">
				<li>商店總覽</li>
				<li><a href="menu.php?res=hauchang">後倉</a></li>
				<li><a href="menu.php?res=db">低逼</a></li>
				<li><a href="menu.php?res=chuanting">穿停</a></li>
				<li><a href="menu.php?res=res1">res1</a></li>
				<li><a href="menu.php?res=res2">res2</a></li>
				<li><a href="menu.php?res=res3">res3</a></li>
				<li><a href="menu.php?res=res4">res4</a></li>
				<li><a href="menu.php?res=res5">res5</a></li>
			</ul>
		</div>
		<div class="maincontent">
			<div class="login">
				<h1>請先登入會員</h1><br/><br/>
				<a href="login.php">點我回登入頁</a>
			</div>
		</div>
	</div>
	

</body>
</html>
_END;
}

?>