<?php
/*require_once "login_info.php";
$db_server=mysqli_connect($db_hostname,$db_username,$db_password,$db_database);
if(!$db_server)die("Unable to connect to MySQL: ".mysql_error());*/
include("connect.php");

session_start();

if (isset($_SESSION['res'])) {
	$res=$_SESSION['res'];
}

if(isset($_GET['logout'])){
	unset($_SESSION['res']);
}

echo <<<_END

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Let's Ordering</title>
	<link rel="stylesheet" type="text/css" href="css/manager.css">
</head>
<body>
	<div class="wrap">
		<div class="header">
		<a href="index.php"><img src="img/LOGO.png"></a>
		<div class="ezlogin">
_END;
			$query="SELECT * FROM manager WHERE res_name='$res'";
			$result=mysqli_query($conn,$query);
			$row=mysqli_fetch_row($result);
			echo "歡迎，$row[2]!&nbsp;&nbsp;";
			echo "<a href='menu.php?logout=true'>登出</a>";
echo <<<_END
		</div>
		</div>
		<div class="operation">
			<h1>Menu</h1>
		</div>
		<div class="sidebar">
			<ul class="sidebars">
				<li>操作項目</li>
				<li><a href="manager_menu.php">菜單管理</a></li>
				<li><a href="manager_orders.php">訂單管理</a></li>
			</ul>
		</div>
		<div class="maincontent">
		<form enctype="multipart/form-data" method="post" action="manager_uploadmenu.php">
				商品圖片：<br />
				<input type="file" name="filename" />
	  			<input type="submit" value="上傳"/></form>

_END;

$imgname="tmp";
$ext="";
if($_FILES){
	$name=$_FILES['filename']['name'];

	switch ($_FILES['filename']['type']) {
		case 'image/jpeg': $ext='jpg';break;
		case 'image/gif': $ext='gif';break;
		case 'image/png': $ext='png';break;
		case 'image/tiff': $ext='tif';break;
		default: $ext=''; break;
	}
	//echo $_FILES['filename']['tmp_name'];

	$n="";
	if($ext){
		$n="menuinfo/$res/$imgname.$ext";
		//echo $n;
		move_uploaded_file($_FILES['filename']['tmp_name'], $n);
		echo "<br/><img src='$n' width='300px' height='300px' />";
		//echo $ext;
	}

}else{
echo "filenull";
}

echo <<<_END

			<form action="manager_menu.php" method="post" accept-charset="utf-8">
				商品名稱：<input type="text" name="in_pro_name" /><br/>
				商品種類：<input type="text" name="in_type_name" /><br/>
_END;
				echo "<input type='hidden' name='in_ext' value='$ext' />";
echo <<<_END
				<input type="hidden" name="sth_in" value="true" />
				商品價格：<input type="text" name="in_pro_price" /><br/><br/>
				<input type="submit" value="儲存" />
			</form>
		</div>
	</div>
</body>
</html>

_END;

/*if ($_POST) {
	$ext=$_POST['ext'];
	$imgname=$_POST['pro_name'];
	echo $tmppath;
	copy("menuinfo/$res/tmp.$ext", "menuinfo/$res/$imgname.$ext");
}*/



?>

