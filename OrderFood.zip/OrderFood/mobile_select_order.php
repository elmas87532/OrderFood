<?php
session_start();
include 'connect.php';

if (isset($_SESSION['u_id'])){

	$u_id=$_SESSION['u_id'];

echo <<<_END
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Let's Ordering</title>
	<link rel="stylesheet" type="text/css" href="css/mobile.css">
</head>
<body>
	<div class="wrap">
		<div class="header">
		<a href="index.php"><img src="img/LOGO.png"></a>
		<div class="ezlogin">
_END;
			$query="SELECT * FROM user WHERE u_id='$u_id'";
			$result=mysqli_query($conn,$query);
			$row=mysqli_fetch_row($result);
			echo "安安，$row[2]!&nbsp;&nbsp;";
			echo "<a href='mobile_select_order.php'>訂單查詢</a>&nbsp;&nbsp;";
			echo "<a href='mobile_menu.php?logout=true'>登出</a>";
echo <<<_END
		</div>
		</div>
		
		<div>
			<ul class="nav1">
				<li><a href="mobile_menu.php?res=hauchang">後倉</a></li>
				<li><a href="mobile_menu.php?res=db">低逼</a></li>
				<li><a href="mobile_menu.php?res=chuanting">穿停</a></li>
				<li><a href="mobile_menu.php?res=res1">res1</a></li>
			</ul>
			<ul class="nav2">
				<li><a href="mobile_menu.php?res=res2">res2</a></li>
				<li><a href="mobile_menu.php?res=res3">res3</a></li>
				<li><a href="mobile_menu.php?res=res4">res4</a></li>
				<li><a href="mobile_menu.php?res=res5">res5</a></li>
			</ul>
		</div>
		<div class="maincontent">
_END;

echo "<table><tr><th>訂單編號</th><th>日期</th><th>狀態</th></tr>";
$query="SELECT * FROM orders WHERE u_id='$u_id'";
$result=mysqli_query($conn,$query);
while($row=mysqli_fetch_row($result)){
	echo "<tr><td><a href='mobile_order_detail.php?o_id_n=$row[4]'>$row[4]</a></td><td>$row[2]</td><td>$row[3]</td></tr>";
}
echo "</table>";


}else{
echo <<<_END
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Let's Ordering</title>
	<link rel="stylesheet" type="text/css" href="css/mobile.css">
</head>
<body>
	<div class="wrap">
		<div class="header">
		<a href="index.php"><img src="img/LOGO.png"></a>
		</div>
		
		<div>
			<ul class="nav1">
				<li><a href="mobile_menu.php?res=hauchang">後倉</a></li>
				<li><a href="mobile_menu.php?res=db">低逼</a></li>
				<li><a href="mobile_menu.php?res=chuanting">穿停</a></li>
				<li><a href="mobile_menu.php?res=res1">res1</a></li>
			</ul>
			<ul class="nav2">
				<li><a href="mobile_menu.php?res=res2">res2</a></li>
				<li><a href="mobile_menu.php?res=res3">res3</a></li>
				<li><a href="mobile_menu.php?res=res4">res4</a></li>
				<li><a href="mobile_menu.php?res=res5">res5</a></li>
			</ul>
		</div>
		<div class="maincontent">
			<div class="login">
				<h1>請先登入會員</h1><br/><br/>
				<a href="mobile_login.php">點我回登入頁</a>
			</div>
		</div>
	</div>
	

</body>
</html>
_END;
}
?>