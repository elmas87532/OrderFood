<?php
include 'connect.php';

if (isset($_POST['have_sign'])) {
	
	if(isset($_POST['u_name']) && $_POST['u_name']!=null){
		$u_name=$_POST['u_name'];
	}else{
		$u_name="";
		//echo "<script>alert('姓名不可空白！')</script>";
		header("Location: mobile_sign.php?none=name");
	}
	if(isset($_POST['u_pw']) && $_POST['u_pw']!=null){
		$u_pw=$_POST['u_pw'];
	}else{
		$u_pw="";
		//echo "<script>alert('密碼不可空白！')</script>";
		header("Location: mobile_sign.php?none=pw");
	}
	if(isset($_POST['u_id']) && $_POST['u_id']!=null){
		$u_id=$_POST['u_id'];
	}else{
		$u_id="";
		//echo "<script>alert('帳號不可空白！')</script>";
		header("Location: mobile_sign.php?none=id");
	}
	if(isset($_POST['u_gender']) && $_POST['u_gender']!=null){
		$u_gender=$_POST['u_gender'];
	}else{
		$u_gender="";
	}
	if(isset($_POST['u_birth']) && $_POST['u_birth']!=null){
		$u_birth=$_POST['u_birth'];
	}else{
		$u_birth="";
	}
	if(isset($_POST['u_phone']) && $_POST['u_phone']!=null){
		$u_phone=$_POST['u_phone'];
	}else{
		$u_phone="";
	}
	if(isset($_POST['u_cphone']) && $_POST['u_cphone']!=null){
		$u_cphone=$_POST['u_cphone'];
	}else{
		$u_cphone="";
	}
	if(isset($_POST['u_address']) && $_POST['u_address']!=null){
		$u_address=$_POST['u_address'];
	}else{
		$u_address="";
	}

	

	if ($u_id!=null && $u_pw!=null && $u_name!=null) {
		$query="SELECT u_id FROM user WHERE u_id='$u_id'";
		$result=mysqli_query($conn,$query);
		$row=mysqli_fetch_row($result);
		if ($row[0]==null) {
			$query="INSERT INTO user(u_id,u_pw,u_name,u_gender,u_birth,u_phone,u_cphone,u_address) VALUES('$u_id','$u_pw','$u_name','$u_gender','$u_birth','$u_phone','$u_cphone','$u_address')";
			mysqli_query($conn,$query);
		}else{
			header("Location: mobile_sign.php?idyet=exist");
		}
	}
	/*$query="INSERT INTO user(u_id,u_pw,u_name,u_gender,u_birth,u_phone,u_cphone,u_address) VALUES('$u_id','$u_pw','$u_name','$u_gender','$u_birth','$u_phone','$u_cphone','$u_address')";
	mysqli_query($conn,$query);*/
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Let's Ordering</title>
	<link rel="stylesheet" type="text/css" href="css/mobile.css">
</head>
<body>
	<div class="wrap">
		<div class="header">
		<a href="index.php"><img src="img/LOGO.png"></a>
		</div>
		
		<div class="nav">
			<ul>
				<li><a href="mobile_menu.php?res=hauchang">後倉</a></li>
				<li><a href="mobile_menu.php?res=db">低逼</a></li>
				<li><a href="mobile_menu.php?res=chuanting">穿停</a></li>
				<li><a href="mobile_menu.php?res=res1">res1</a></li>
				<li><a href="mobile_menu.php?res=res2">res2</a></li>
				<li><a href="mobile_menu.php?res=res3">res3</a></li>
				<li><a href="mobile_menu.php?res=res4">res4</a></li>
				<li><a href="mobile_menu.php?res=res5">res5</a></li>
			</ul>
		</div>
		<div class="maincontent">
			<div class="stream">
				<h1>註冊完成，請重新登入</h1><br/><br/>
				<a href="mobile_login.php">點我回登入頁</a>
			</div>
		</div>
	</div>
	

</body>
</html>