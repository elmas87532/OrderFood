<?php
session_start();
include 'connect.php';

if (isset($_SESSION['u_id'])){

	$u_id=$_SESSION['u_id'];

echo <<<_END
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Let's Ordering</title>
	<link rel="stylesheet" type="text/css" href="css/mobile.css">
</head>
<body>
	<div class="wrap">
		<div class="header">
		<a href="index.php"><img src="img/LOGO.png"></a>
		<div class="ezlogin">
_END;
			$query="SELECT * FROM user WHERE u_id='$u_id'";
			$result=mysqli_query($conn,$query);
			$row=mysqli_fetch_row($result);
			echo "安安，$row[2]!&nbsp;&nbsp;";
			echo "<a href='mobile_select_order.php'>訂單查詢</a>&nbsp;&nbsp;";
			echo "<a href='mobile_menu.php?logout=true'>登出</a>";
echo <<<_END
		</div>
		</div>
		
		<div>
			<ul class="nav1">
				<li><a href="mobile_menu.php?res=hauchang">後倉</a></li>
				<li><a href="mobile_menu.php?res=db">低逼</a></li>
				<li><a href="mobile_menu.php?res=chuanting">穿停</a></li>
				<li><a href="mobile_menu.php?res=res1">res1</a></li>
			</ul>
			<ul class="nav2">
				<li><a href="mobile_menu.php?res=res2">res2</a></li>
				<li><a href="mobile_menu.php?res=res3">res3</a></li>
				<li><a href="mobile_menu.php?res=res4">res4</a></li>
				<li><a href="mobile_menu.php?res=res5">res5</a></li>
			</ul>
		</div>
		<div class="maincontent">
_END;

$o_id_n=$_GET['o_id_n'];
echo "訂單編號：$o_id_n";
echo "<table><tr><th>編號</th><th>商品</th><th>餐廳</th><th>數量</th><th>價格</th></tr>";
$query="SELECT * FROM order_detail WHERE o_id_n='$o_id_n'";
$result=mysqli_query($conn,$query);
$rows=mysqli_num_rows($result);
for($i=0;$i<$rows;$i++){
	$vi=$i+1;
	$row=mysqli_fetch_row($result);

	switch ($row[2]) {
		case 'hauchang':
			$u_res="後倉";
			break;
		case 'db':
			$u_res="低逼";
			break;
		case 'chuanting':
			$u_res="穿停";
			break;
		case 'res1':
			$u_res="res1";
			break;
		case 'res2':
			$u_res="res2";
			break;
		case 'res3':
			$u_res="res3";
			break;
		case 'res4':
			$u_res="res4";
			break;
		case 'res5':
			$u_res="res5";
			break;
		
		default:
			# code...
			break;
		}

	echo "<tr><td>$vi</td><td>$row[1]</td><td>$u_res</td><td>$row[3]</td><td>$row[4]</td></tr>";
}

}else{
echo <<<_END
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Let's Ordering</title>
	<link rel="stylesheet" type="text/css" href="css/mobile.css">
</head>
<body>
	<div class="wrap">
		<div class="header">
		<a href="index.php"><img src="img/LOGO.png"></a>
		
		<div>
			<ul class="nav1">
				<li><a href="mobile_menu.php?res=hauchang">後倉</a></li>
				<li><a href="mobile_menu.php?res=db">低逼</a></li>
				<li><a href="mobile_menu.php?res=chuanting">穿停</a></li>
				<li><a href="mobile_menu.php?res=res1">res1</a></li>
			</ul>
			<ul class="nav2">
				<li><a href="mobile_menu.php?res=res2">res2</a></li>
				<li><a href="mobile_menu.php?res=res3">res3</a></li>
				<li><a href="mobile_menu.php?res=res4">res4</a></li>
				<li><a href="mobile_menu.php?res=res5">res5</a></li>
			</ul>
		</div>
		<div class="maincontent">
			<div class="login">
				<h1>請先登入會員</h1><br/><br/>
				<a href="mobile_login.php">點我回登入頁</a>
			</div>
		</div>
	</div>
	

</body>
</html>
_END;
}
?>