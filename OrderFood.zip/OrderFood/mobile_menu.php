<?php


include 'connect.php';

session_start();

$res="hauchang";
if (isset($_GET['res'])) {
	$res=$_GET['res'];
	//echo $res;
}

$u_id="";
if(isset($_SESSION['u_id'])){
	$u_id=$_SESSION['u_id'];
}

if(isset($_POST['logined'])){

	$u_id=$_POST['u_id'];
	$u_pw=$_POST['u_pw'];

	//echo "logined";
	$query="SELECT * FROM user WHERE u_id='$u_id'";
	$m_query="SELECT * FROM manager WHERE m_id='$u_id'";
	//echo $query;
	$result=mysqli_query($conn,$query);
	$m_result=mysqli_query($conn,$m_query);


	$row=mysqli_fetch_row($result);
	$m_row=mysqli_fetch_row($m_result);


	if($row[0]!=null && $row[1]!=null && $u_id==$row[0] && $u_pw==$row[1]){
		$_SESSION['u_id']=$row[0];
		$_SESSION['id_type']="user";
	}elseif ($m_row[0]!=null && $m_row[1]!=null && $u_id==$m_row[0] && $u_pw==$m_row[1]) {
		$_SESSION['id_type']="manager";
		header("Location:mobile_manager_menu.php?res=$m_row[2]");
	}else{
		echo "<script>alert('帳號密碼有誤，請重新登入')</script>";
	}
	

}

if(isset($_GET['logout'])){
	unset($_SESSION['u_id']);
}

if(isset($_SESSION['u_id'])){
echo <<<_END

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Let's Ordering</title>
	<link rel="stylesheet" type="text/css" href="css/mobile.css">
</head>
<body>
	<div class="wrap">
		<div class="header">
		<a href="index.php"><img src="img/LOGO.png"></a>
		<div class="ezlogin">
_END;
			$query="SELECT * FROM user WHERE u_id='$u_id'";
			$result=mysqli_query($conn,$query);
			$row=mysqli_fetch_row($result);
			echo "安安，$row[2]!&nbsp;&nbsp;";
			echo "<a href='mobile_select_order.php'>訂單查詢</a>&nbsp;&nbsp;";
			echo "<a href='mobile_menu.php?logout=true'>登出</a>";
echo <<<_END
		</div>
		</div>
		<div>
			<ul class="nav1">
				<li><a href="mobile_menu.php?res=hauchang">後倉</a></li>
				<li><a href="mobile_menu.php?res=db">低逼</a></li>
				<li><a href="mobile_menu.php?res=chuanting">穿停</a></li>
				<li><a href="mobile_menu.php?res=res1">res1</a></li>
			</ul>
			<ul class="nav2">
				<li><a href="mobile_menu.php?res=res2">res2</a></li>
				<li><a href="mobile_menu.php?res=res3">res3</a></li>
				<li><a href="mobile_menu.php?res=res4">res4</a></li>
				<li><a href="mobile_menu.php?res=res5">res5</a></li>
			</ul>
		</div>
		
		<div class="maincontent">
			<div class="top">
			<div class="top_type"></div>
			<div class="top_onc">
				<a href="mobile_cart.php">購物車</a>
			</div>
			</div>
_END;

//$type_name="飯";
$query="SELECT * FROM product WHERE res_name='$res'";
if (isset($_GET['type_name'])) {
	$type_name=$_GET['type_name'];
	$query="SELECT * FROM product WHERE res_name='$res' AND type_name='$type_name'";

}

//$query="SELECT * FROM product WHERE res_name='$res' AND type_name='$type_name'";
$result=mysqli_query($conn,$query);
$rows=mysqli_num_rows($result);
echo "<table>";
echo "<tr><th>圖片</th><th>品名</th><th>價格</th><th>類型</th><th>數量</th><th>加入</th></tr>";
for ($i=1; $i<=$rows; $i++) {
	$row=mysqli_fetch_row($result);
	echo "<tr><td class='pic'><img src='$row[5]' width='200px' height='200px'/></td><td>$row[1]</td><td>$row[2]</td><td>$row[4]</td><form action='mobile_cart.php' method='post'><td><input type='number' name='num' value='1'/><input type='hidden' name='pro_id' value='$row[0]'/></td><td><input type='submit' value='加入購物車'/></td></form></tr>";
}

echo <<<_END
		</div>
	</div>
	

</body>
</html>

_END;
}else{
echo <<<_END

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Let's Ordering</title>
	<link rel="stylesheet" type="text/css" href="css/mobile.css">
</head>
<body>
_END;

echo <<<_END
	<div class="wrap">
		<div class="header">
		<a href="index.php"><img src="img/LOGO.png"></a>
		<div class="ezlogin">
			<a href="mobile_login.php">會員登入</a>&nbsp;&nbsp;&nbsp;<a href="mobile_sign.php">註冊帳號</a>
		</div>
		</div>
		<div>
			<ul class="nav1">
				<li><a href="mobile_menu.php?res=hauchang">後倉</a></li>
				<li><a href="mobile_menu.php?res=db">低逼</a></li>
				<li><a href="mobile_menu.php?res=chuanting">穿停</a></li>
				<li><a href="mobile_menu.php?res=res1">res1</a></li>
			</ul>
			<ul class="nav2">
				<li><a href="mobile_menu.php?res=res2">res2</a></li>
				<li><a href="mobile_menu.php?res=res3">res3</a></li>
				<li><a href="mobile_menu.php?res=res4">res4</a></li>
				<li><a href="mobile_menu.php?res=res5">res5</a></li>
			</ul>
		</div>
		<div class="maincontent">
			<div class="top">
			<div class="top_type">
			</div>
			<div class="top_onc">
				<a href="mobile_login.php">購物車</a>
			</div>
			</div>
_END;

$query="SELECT * FROM product WHERE res_name='$res'";

if (isset($_GET['type_name'])) {
	$type_name=$_GET['type_name'];
	$query="SELECT * FROM product WHERE res_name='$res' AND type_name='$type_name'";
}

$result=mysqli_query($conn,$query);
$rows=mysqli_num_rows($result);
echo "<table>";
echo "<tr><th>圖片</th><th>品名</th><th>價格</th><th>類型</th><th>數量</th><th>加入</th></tr>";
for ($i=1; $i<=$rows; $i++) {
	$row=mysqli_fetch_row($result);
	echo "<tr><td class='pic'><img src='$row[5]' width='200px' height='200px'/></td><td>$row[1]</td><td>$row[2]</td><td>$row[4]</td><form action='mobile_login.php' method='post'><td><input type='number' name='num'/></td><td><input type='submit' value='加入購物車'/></td></form></tr>";
}

echo <<<_END
		</div>
	</div>
	

</body>
</html>

_END;
}
?>


