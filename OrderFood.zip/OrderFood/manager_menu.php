<?php
/*$conn=mysqli_connect("localhost","foood","abc123","order_system");
if(!$conn)die("Unable to connect to MySQL: ".mysql_error());*/

include("connect.php");

session_start();

if (isset($_GET['res'])) {
	$_SESSION['res']=$_GET['res'];
}

$res=$_SESSION['res'];

if (isset($_POST['sth_in'])) {
	$ext=$_POST['in_ext'];
	$imgname=$_POST['in_pro_name'];
	$type_name=$_POST['in_type_name'];
	$pro_price=(int)$_POST['in_pro_price'];
	$pro_path="menuinfo/$res/$imgname.$ext";
	copy("menuinfo/$res/tmp.$ext", iconv("UTF-8","big5","menuinfo/$res/$imgname.$ext"));
	$query="INSERT INTO product(pro_name,pro_price,res_name,type_name,pro_path) VALUES('$imgname',$pro_price,'$res','$type_name','$pro_path')";
	mysqli_select_db($conn,"order_system");
	mysqli_query($conn,$query);
	//echo $query;
}

if(isset($_GET['dl_pro_id'])){
	$dl_pro_id=$_GET['dl_pro_id'];
	$query="DELETE FROM product WHERE pro_id=$dl_pro_id";
	mysqli_query($conn,$query);
}

if(isset($_POST['up_pro_id'])){
	$up_pro_id=$_POST['up_pro_id'];
	$up_pro_name=$_POST['up_pro_name'];
	$up_pro_price=(int)$_POST['up_pro_price'];
	$up_type_name=$_POST['up_type_name'];
	$up_pro_path="";
	$unup_pro_path=$_POST['unup_pro_path'];
	if (isset($_POST['have_ext'])) {
		$up_pro_ext=$_POST['up_pro_ext'];
		$up_pro_path="menuinfo/$res/$up_pro_name.$up_pro_ext";
	}else {
		$up_pro_path=$unup_pro_path;
	}
	copy("menuinfo/$res/tmp.$up_pro_ext", iconv("UTF-8","big5",$up_pro_path));
	$query="UPDATE product SET pro_name='$up_pro_name',pro_price='$up_pro_price',type_name='$up_type_name',pro_path='$up_pro_path' WHERE pro_id=$up_pro_id";
	mysqli_query($conn,$query);
	//echo $query;
}

if(isset($_GET['logout'])){
	unset($_SESSION['res']);
}

echo <<<_END
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Let's Ordering</title>
	<link rel="stylesheet" type="text/css" href="css/manager.css">
</head>
<body>
	<div class="wrap">
		<div class="header">
		<a href="index.php"><img src="img/LOGO.png"></a>
		<div class="ezlogin">
_END;
			$query="SELECT * FROM manager WHERE res_name='$res'";
			$result=mysqli_query($conn,$query);
			$row=mysqli_fetch_row($result);
			echo "歡迎，$row[2]!&nbsp;&nbsp;";
			echo "<a href='menu.php?logout=true'>登出</a>";
echo <<<_END
		</div>
		</div>
		<div class="operation">
			<h1>Menu</h1>
		</div>
		<div class="sidebar">
			<ul class="sidebars">
				<li>操作項目</li>
				<li><a href="manager_menu.php">菜單管理</a></li>
				<li><a href="manager_orders.php">訂單管理</a></li>
			</ul>
		</div>
		<div class="maincontent">
			<p class="uploadmenu"><a href="manager_uploadmenu.php">+新增菜單</a></p>
_END;

$query="SELECT * FROM product WHERE res_name='$res'";
$result=mysqli_query($conn,$query);
$rows=mysqli_num_rows($result);
echo "<table class='menu'>";
echo "<tr class='titletr'><td>編號</td><td>圖片</td><td>品名</td><td>價格</td><td>類別</td><td>修改</td><td>刪除</td></tr>";
for ($i=1;$i<=$rows;$i++) {
	$row=mysqli_fetch_row($result);
	echo "<tr><td>$i</td><td><img src='$row[5]' width='150px' height='150px'/></td><td>$row[1]</td><td>$row[2]</td><td>$row[4]</td>";
	echo "<td><a href='manager_update.php?up_pro_id=$row[0]'>修改</a></td><td><a href='manager_menu.php?dl_pro_id=$row[0]'>刪除</a></td>";
}
echo "</table>";

echo <<<_END
		</div>
	</div>
</body>
</html>
_END;
?>
