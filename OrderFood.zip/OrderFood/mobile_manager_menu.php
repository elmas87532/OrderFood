<?php
/*$conn=mysqli_connect("localhost","foood","abc123","order_system");
if(!$conn)die("Unable to connect to MySQL: ".mysql_error());*/

include("connect.php");

session_start();

if (isset($_GET['res'])) {
	$_SESSION['res']=$_GET['res'];
}

$res=$_SESSION['res'];

if (isset($_POST['sth_in'])) {
	$ext=$_POST['in_ext'];
	$imgname=$_POST['in_pro_name'];
	$type_name=$_POST['in_type_name'];
	$pro_price=(int)$_POST['in_pro_price'];
	$pro_path="menuinfo/$res/$imgname.$ext";
	copy("menuinfo/$res/tmp.$ext", iconv("UTF-8","big5","menuinfo/$res/$imgname.$ext"));
	$query="INSERT INTO product(pro_name,pro_price,res_name,type_name,pro_path) VALUES('$imgname',$pro_price,'$res','$type_name','$pro_path')";
	mysqli_select_db($conn,"order_system");
	mysqli_query($conn,$query);
	//echo $query;
}

if(isset($_GET['dl_pro_id'])){
	$dl_pro_id=$_GET['dl_pro_id'];
	$query="DELETE FROM product WHERE pro_id=$dl_pro_id";
	mysqli_query($conn,$query);
}

if(isset($_POST['up_pro_id'])){
	$up_pro_id=$_POST['up_pro_id'];
	$up_pro_name=$_POST['up_pro_name'];
	$up_pro_price=(int)$_POST['up_pro_price'];
	$up_type_name=$_POST['up_type_name'];
	$up_pro_path="";
	$unup_pro_path=$_POST['unup_pro_path'];
	if (isset($_POST['have_ext'])) {
		$up_pro_ext=$_POST['up_pro_ext'];
		$up_pro_path="menuinfo/$res/$up_pro_name.$up_pro_ext";
	}else {
		$up_pro_path=$unup_pro_path;
	}
	copy("menuinfo/$res/tmp.$up_pro_ext", iconv("UTF-8","big5",$up_pro_path));
	$query="UPDATE product SET pro_name='$up_pro_name',pro_price='$up_pro_price',type_name='$up_type_name',pro_path='$up_pro_path' WHERE pro_id=$up_pro_id";
	mysqli_query($conn,$query);
	//echo $query;
}

if(isset($_GET['logout'])){
	unset($_SESSION['res']);
}

echo <<<_END
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Let's Ordering</title>
	<link rel="stylesheet" type="text/css" href="css/mobile.css">
</head>
<body>
	<div class="wrap">
		<div class="header">
		<a href="index.php"><img src="img/LOGO.png"></a>
		<div class="ezlogin">
_END;
			$query="SELECT * FROM manager WHERE res_name='$res'";
			$result=mysqli_query($conn,$query);
			$row=mysqli_fetch_row($result);
			echo "歡迎，$row[2]!&nbsp;&nbsp;";
			echo "<a href='mobile_menu.php?logout=true'>登出</a>";
echo <<<_END
		</div>
		</div>
		<div class="nav">
			<ul>
				<li><a href="mobile_manager_.php?res=res2">菜單管理</a></li>
				<li><a href="mobile_manager_orders.php?res=res3">訂單管理</a></li>
			</ul>
		</div>
		<div class="mtop">
			<p class="uploadmenu"><a href="mobile_manager_uploadmenu.php">+新增菜單</a></p></div>
_END;

$query="SELECT * FROM product WHERE res_name='$res'";
$result=mysqli_query($conn,$query);
$rows=mysqli_num_rows($result);
echo "<table>";
echo "<tr class='titletr'><th class='man'>編號</th><th class='man'>圖片</th><th class='man'>品名</th><th class='man'>價格</th><th class='man'>修改</th><th class='man'>刪除</th></tr>";
for ($i=1;$i<=$rows;$i++) {
	$row=mysqli_fetch_row($result);
	echo "<tr><td>$i</td><td class='pic'><img src='$row[5]' width='250px' height='250px'/></td><td>$row[1]</td><td>$row[2]</td>";
	echo "<td><a href='mobile_manager_update.php?up_pro_id=$row[0]'>修改</a></td><td><a href='mobile_manager_menu.php?dl_pro_id=$row[0]'>刪除</a></td>";
}
echo "</table>";

echo <<<_END
		
	</div>
</body>
</html>
_END;
?>
