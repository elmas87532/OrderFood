<?php
include 'connect.php';
session_start();

if (isset($_SESSION['u_id'])) {

	$u_id=$_SESSION['u_id'];
	$cart_items=$_SESSION['items'];
	$cart_num=$_SESSION['num'];

if($_POST['getway']=="send" && $_POST['address']==null){
	header("Location:check_address.php?nulladdress=true");
}else{
	$_SESSION['getway']=$_POST['address'];
}

if($_POST['getway']=="byself"){
	$_SESSION['getway']=$_POST['getway'];
}

if(isset($_POST['gettime'])){
	$_SESSION['gettime']=$_POST['gettime'];
}

echo <<<_END
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Let's Ordering</title>
	<link rel="stylesheet" type="text/css" href="css/all.css">
</head>
<body>
	<div class="wrap">
		<div class="header">
		<a href="index.php"><img src="img/LOGO.png"></a>
		<div class="ezlogin">
_END;
			$query="SELECT * FROM user WHERE u_id='$u_id'";
			$result=mysqli_query($conn,$query);
			$row=mysqli_fetch_row($result);
			echo "安安，$row[2]!&nbsp;&nbsp;";
			echo "<a href='select_order.php'>訂單查詢</a>&nbsp;&nbsp;";
			echo "<a href='menu.php?logout=true'>登出</a>";
echo <<<_END
		</div>
		</div>
		<div class="operation">
			<h1>Menu</h1>
		</div>
		<div class="sidebar">
			<ul class="sidebars">
				<li>商店總覽</li>
				<li><a href="menu.php?res=hauchang">後倉</a></li>
				<li><a href="menu.php?res=db">低逼</a></li>
				<li><a href="menu.php?res=chuanting">穿停</a></li>
				<li><a href="menu.php?res=res1">res1</a></li>
				<li><a href="menu.php?res=res2">res2</a></li>
				<li><a href="menu.php?res=res3">res3</a></li>
				<li><a href="menu.php?res=res4">res4</a></li>
				<li><a href="menu.php?res=res5">res5</a></li>
			</ul>
		</div>
		<div class="maincontent">
_END;
	echo "<table><tr><th>編號</th><th>名稱</th><th>餐廳</th><th>數量</th><th>價格</th></tr>";
	$sum=0;
	$tmp_item=$_SESSION['items'];
	$tmp_num=$_SESSION['num'];
	for($i=0;$i<count($_SESSION['items']);$i++){
		$query="SELECT * FROM product WHERE pro_id='$tmp_item[$i]'";
		$result=mysqli_query($conn,$query);
		$row=mysqli_fetch_row($result); 
		$total_price=$row[2]*$tmp_num[$i];
		$sum=$sum+$total_price;
		$vi=$i+1;

		switch ($row[3]) {
		case 'hauchang':
			$u_res="後倉";
			break;
		case 'db':
			$u_res="低逼";
			break;
		case 'chuanting':
			$u_res="穿停";
			break;
		case 'res1':
			$u_res="res1";
			break;
		case 'res2':
			$u_res="res2";
			break;
		case 'res3':
			$u_res="res3";
			break;
		case 'res4':
			$u_res="res4";
			break;
		case 'res5':
			$u_res="res5";
			break;
		
		default:
			# code...
			break;
		}

		echo "<tr><td>$vi</td><td>$row[1]</td><td>$u_res</td><td>$tmp_num[$i]</td><td>$total_price</td></tr>";
	}
	echo "<tr class='line'><td colspan='5' class='o_sum'>總金額：$sum</td></tr>";
	echo "<tr class='line'><td colspan='5' class='o_sum'>付款方式：";
	if ($_SESSION['getway']=="byself") {
		echo "自取";
	}else{
		$address=$_SESSION['getway'];
		echo "外送，地址：$address";
	}
	
	echo "</td></tr></table>";
	/*if (isset($_POST['gettime'])) {
		$_SESSION['gettime']=$_POST['gettime'];
		echo "取餐時間：$_SESSION['gettime']";
	}*/
echo <<<_END

<div class="stream">
<a href="check_address.php">回上一頁</a>
<a href="order.php">確認送出</a>
</div>

_END;

}else{
echo <<<_END
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Let's Ordering</title>
	<link rel="stylesheet" type="text/css" href="css/lns.css">
</head>
<body>
	<div class="wrap">
		<div class="header">
		<a href="index.php"><img src="img/LOGO.png"></a>
		</div>
		<div class="operation">
			<h1>Login</h1>
		</div>
		<div class="sidebar">
			<ul class="sidebars">
				<li>商店總覽</li>
				<li><a href="menu.php?res=hauchang">後倉</a></li>
				<li><a href="menu.php?res=db">低逼</a></li>
				<li><a href="menu.php?res=chuanting">穿停</a></li>
				<li><a href="menu.php?res=res1">res1</a></li>
				<li><a href="menu.php?res=res2">res2</a></li>
				<li><a href="menu.php?res=res3">res3</a></li>
				<li><a href="menu.php?res=res4">res4</a></li>
				<li><a href="menu.php?res=res5">res5</a></li>
			</ul>
		</div>
		<div class="maincontent">
			<div class="login">
				<h1>請先登入會員</h1><br/><br/>
				<a href="login.php">點我回登入頁</a>
			</div>
		</div>
	</div>
	

</body>
</html>
_END;
}

?>