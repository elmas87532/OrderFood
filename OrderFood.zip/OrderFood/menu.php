<?php
/*-------------------------------------------------------------------------------*/
include 'connect.php';
 $mobile_browser = '0';
 
if(preg_match('/(up.browser|up.link|mmp|symbian|smartphone|midp|wap|phone)/i', strtolower($_SERVER['HTTP_USER_AGENT']))) {
    $mobile_browser++;
}
 
if((strpos(strtolower($_SERVER['HTTP_ACCEPT']),'application/vnd.wap.xhtml+xml')>0) or ((isset($_SERVER['HTTP_X_WAP_PROFILE']) or isset($_SERVER['HTTP_PROFILE'])))) {
    $mobile_browser++;
}    
 
$mobile_ua = strtolower(substr($_SERVER['HTTP_USER_AGENT'],0,4));
$mobile_agents = array(
    'w3c ','acs-','alav','alca','amoi','audi','avan','benq','bird','blac',
    'blaz','brew','cell','cldc','cmd-','dang','doco','eric','hipt','inno',
    'ipaq','java','jigs','kddi','keji','leno','lg-c','lg-d','lg-g','lge-',
    'maui','maxo','midp','mits','mmef','mobi','mot-','moto','mwbp','nec-',
    'newt','noki','oper','palm','pana','pant','phil','play','port','prox',
    'qwap','sage','sams','sany','sch-','sec-','send','seri','sgh-','shar',
    'sie-','siem','smal','smar','sony','sph-','symb','t-mo','teli','tim-',
    'tosh','tsm-','upg1','upsi','vk-v','voda','wap-','wapa','wapi','wapp',
    'wapr','webc','winw','winw','xda','xda-','Googlebot-Mobile');
 
if(in_array($mobile_ua,$mobile_agents)) {
    $mobile_browser++;
}
 
if (strpos(strtolower($_SERVER['ALL_HTTP']),'OperaMini')>0) {
    $mobile_browser++;
}
 
if (strpos(strtolower($_SERVER['HTTP_USER_AGENT']),'windows')>0) {
    $mobile_browser=0;
}
 
if($mobile_browser>0) {
	header("Location: mobile_menu.php"); //手機版
	//echo "cellphone";
}else {
	//header("Location: pc.php");  //電腦版
	echo "PC";
	//echo "電腦版";

}
/*-------------------------------------------------------------------------------*/

include 'connect.php';

session_start();

$res="hauchang";
if (isset($_GET['res'])) {
	$res=$_GET['res'];
	//echo $res;
}

$u_id="";
if(isset($_SESSION['u_id'])){
	$u_id=$_SESSION['u_id'];
}

if(isset($_POST['logined'])){

	$u_id=$_POST['u_id'];
	$u_pw=$_POST['u_pw'];

	//echo "logined";
	$query="SELECT * FROM user WHERE u_id='$u_id'";
	$m_query="SELECT * FROM manager WHERE m_id='$u_id'";
	//echo $query;
	$result=mysqli_query($conn,$query);
	$m_result=mysqli_query($conn,$m_query);


	$row=mysqli_fetch_row($result);
	$m_row=mysqli_fetch_row($m_result);


	if($row[0]!=null && $row[1]!=null && $u_id==$row[0] && $u_pw==$row[1]){
		$_SESSION['u_id']=$row[0];
		$_SESSION['id_type']="user";
	}elseif ($m_row[0]!=null && $m_row[1]!=null && $u_id==$m_row[0] && $u_pw==$m_row[1]) {
		$_SESSION['id_type']="manager";
		header("Location:manager_menu.php?res=$m_row[2]");
	}else{
		echo "<script>alert('帳號密碼有誤，請重新登入')</script>";
	}
	

}

if(isset($_GET['logout'])){
	unset($_SESSION['u_id']);
}

if(isset($_SESSION['u_id'])){
echo <<<_END

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Let's Ordering</title>
	<link rel="stylesheet" type="text/css" href="css/all.css">
</head>
<body>
	<div class="wrap">
		<div class="header">
		<a href="index.php"><img src="img/LOGO.png"></a>
		<div class="ezlogin">
_END;
			$query="SELECT * FROM user WHERE u_id='$u_id'";
			$result=mysqli_query($conn,$query);
			$row=mysqli_fetch_row($result);
			echo "安安，$row[2]!&nbsp;&nbsp;";
			echo "<a href='select_order.php'>訂單查詢</a>&nbsp;&nbsp;";
			echo "<a href='menu.php?logout=true'>登出</a>";
echo <<<_END
		</div>
		</div>
		<div class="operation">
			<h1>Menu</h1>
		</div>
		<div class="sidebar">
			<ul class="sidebars">
				<li>商店總覽</li>
				<li><a href="menu.php?res=hauchang">後倉</a></li>
				<li><a href="menu.php?res=db">低逼</a></li>
				<li><a href="menu.php?res=chuanting">穿停</a></li>
				<li><a href="menu.php?res=res1">res1</a></li>
				<li><a href="menu.php?res=res2">res2</a></li>
				<li><a href="menu.php?res=res3">res3</a></li>
				<li><a href="menu.php?res=res4">res4</a></li>
				<li><a href="menu.php?res=res5">res5</a></li>
			</ul>
		</div>
		<div class="maincontent">
			<div class="top_type">
				<select onChange="location = this.options[this.selectedIndex].value;" size="1">
					<option value="#">商品種類</option>
					<option value="menu.php?res=$res">全部商品</option>
					<option value="menu.php?type_name=飯&res=$res">飯</option>
					<option value="menu.php?type_name=麵&res=$res">麵</option>
					<option value="menu.php?type_name=湯&res=$res">湯</option>
				</select>
			</div>
			<div class="top_onc">
				<a href="cart.php">購物車</a>
			</div>
_END;

//$type_name="飯";
$query="SELECT * FROM product WHERE res_name='$res'";
if (isset($_GET['type_name'])) {
	$type_name=$_GET['type_name'];
	$query="SELECT * FROM product WHERE res_name='$res' AND type_name='$type_name'";

}

//$query="SELECT * FROM product WHERE res_name='$res' AND type_name='$type_name'";
$result=mysqli_query($conn,$query);
$rows=mysqli_num_rows($result);
echo "<table>";
echo "<tr><th>編號</th><th>圖片</th><th>品名</th><th>價格</th><th>類型</th><th>數量</th><th>加入</th></tr>";
for ($i=1; $i<=$rows; $i++) {
	$row=mysqli_fetch_row($result);
	echo "<tr><td>$i</td><td><img src='$row[5]' width='200px' height='200px'/></td><td>$row[1]</td><td>$row[2]</td><td>$row[4]</td><form action='cart.php' method='post'><td><input type='number' name='num' value='1'/><input type='hidden' name='pro_id' value='$row[0]'/></td><td><input type='submit' value='加入購物車'/></td></form></tr>";
}

echo <<<_END
		</div>
	</div>
	

</body>
</html>

_END;
}else{
echo <<<_END

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Let's Ordering</title>
	<link rel="stylesheet" type="text/css" href="css/all.css">
</head>
<body>
_END;

echo <<<_END
	<div class="wrap">
		<div class="header">
		<a href="index.php"><img src="img/LOGO.png"></a>
		<div class="ezlogin">
			<a href="login.php">會員登入</a>&nbsp;&nbsp;&nbsp;<a href="sign.php">註冊帳號</a>
		</div>
		</div>
		<div class="operation">
			<h1>Menu</h1>
		</div>
		<div class="sidebar">
			<ul class="sidebars">
				<li>商店總覽</li>
				<li><a href="menu.php?res=hauchang">後倉</a></li>
				<li><a href="menu.php?res=db">低逼</a></li>
				<li><a href="menu.php?res=chuanting">穿停</a></li>
				<li><a href="menu.php?res=res1">res1</a></li>
				<li><a href="menu.php?res=res2">res2</a></li>
				<li><a href="menu.php?res=res3">res3</a></li>
				<li><a href="menu.php?res=res4">res4</a></li>
				<li><a href="menu.php?res=res5">res5</a></li>
			</ul>
		</div>
		<div class="maincontent">
			<div class="top_type">
				<select onChange="location = this.options[this.selectedIndex].value;" size="1">
					<option value="#">全部商品</option>
					<option value="menu.php?type_name=飯&res=$res">飯</option>
					<option value="menu.php?type_name=麵&res=$res">麵</option>
					<option value="menu.php?type_name=湯&res=$res">湯</option>
				</select>
			</div>
			<div class="top_onc">
				<a href="login.php">購物車</a>
			</div>
_END;

$query="SELECT * FROM product WHERE res_name='$res'";

if (isset($_GET['type_name'])) {
	$type_name=$_GET['type_name'];
	$query="SELECT * FROM product WHERE res_name='$res' AND type_name='$type_name'";
}

$result=mysqli_query($conn,$query);
$rows=mysqli_num_rows($result);
echo "<table>";
echo "<tr><th>編號</th><th>圖片</th><th>品名</th><th>價格</th><th>類型</th><th>數量</th><th>加入</th></tr>";
for ($i=1; $i<=$rows; $i++) {
	$row=mysqli_fetch_row($result);
	echo "<tr><td>$i</td><td><img src='$row[5]' width='200px' height='200px'/></td><td>$row[1]</td><td>$row[2]</td><td>$row[4]</td><form action='login.php' method='post'><td><input type='number' name='num'/></td><td><input type='submit' value='加入購物車'/></td></form></tr>";
}

echo <<<_END
		</div>
	</div>
	

</body>
</html>

_END;
}
?>


