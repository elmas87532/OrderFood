<?php
/*$conn=mysqli_connect("localhost","foood","abc123","order_system");
if(!$conn)die("Unable to connect to MySQL: ".mysql_error());*/

include("connect.php");

session_start();

if (isset($_GET['res'])) {
	$_SESSION['res']=$_GET['res'];
}


$res=$_SESSION['res'];


if(isset($_GET['logout'])){
	unset($_SESSION['res']);
}

if(isset($_GET['delete_o_id_n'])){
	$delete_id=$_GET['delete_o_id_n'];
	$query="DELETE FROM orders WHERE o_id_n='$delete_id'";
	mysqli_query($conn,$query);
}

if (isset($_GET['stat']) && $_GET['o_id_n']) {
	$id=$_GET['o_id_n'];
	$query="UPDATE orders SET o_stat='取餐完成' WHERE o_id_n='$id'";
	mysqli_query($conn,$query);
}

echo <<<_END
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Let's Ordering</title>
	<link rel="stylesheet" type="text/css" href="css/manager.css">
</head>
<body>
	<div class="wrap">
		<div class="header">
		<a href="index.php"><img src="img/LOGO.png"></a>
		<div class="ezlogin">
_END;
			$query="SELECT * FROM manager WHERE res_name='$res'";
			$result=mysqli_query($conn,$query);
			$row=mysqli_fetch_row($result);
			echo "歡迎，$row[2]!&nbsp;&nbsp;";
			echo "<a href='menu.php?logout=true'>登出</a>";
echo <<<_END
		</div>
		</div>
		<div class="operation">
			<h1>Menu</h1>
		</div>
		<div class="sidebar">
			<ul class="sidebars">
				<li>操作項目</li>
				<li><a href="manager_menu.php">菜單管理</a></li>
				<li><a href="manager_orders.php">訂單管理</a></li>
			</ul>
		</div>
		<div class="maincontent">
_END;

echo "<table class='order'><tr class='titletr'><td>訂單編號</td><td>訂購者</td><td>訂購時間</td><td>狀態</td><td>刪除</td></tr>";

$fp_csv=fopen("csv/orders_$res.csv", "w");
$th1=mb_convert_encoding("訂單編號","Big5","UTF-8");
$th2=mb_convert_encoding("訂購者","Big5","UTF-8");
$th3=mb_convert_encoding("訂購時間","Big5","UTF-8");
$th4=mb_convert_encoding("狀態","Big5","UTF-8");
fputs($fp_csv,"$th1,$th2,$th3,$th4\n");

$query="SELECT DISTINCT o_id_n FROM order_detail WHERE res_name='$res'";
$result=mysqli_query($conn,$query);
$o_id_ns=array();
while ($row=mysqli_fetch_row($result)) {
	$o_query="SELECT * FROM orders WHERE o_id_n='$row[0]'";
	//echo $o_query;
	$o_result=mysqli_query($conn,$o_query);
	while ($o_row=mysqli_fetch_row($o_result)) {
		echo "<tr><td><a href='manager_order_detail.php?o_id_n=$o_row[4]'>$o_row[4]</a></td><td>$o_row[1]</td><td>$o_row[2]</td><td>$o_row[3]</td><td><a href='manager_orders.php?delete_o_id_n=$o_row[4]'>刪除訂單</a></td></tr>";

		$c1=mb_convert_encoding($o_row[4],"Big5","UTF-8");
		$c2=mb_convert_encoding($o_row[1],"Big5","UTF-8");
		$c3=mb_convert_encoding($o_row[2],"Big5","UTF-8");
		$c4=mb_convert_encoding($o_row[3],"Big5","UTF-8");
		fputs($fp_csv,"$c1,$c2,$c3,$c4\n");

	}
}
fclose($fp_csv);
echo "</table>";

	
echo <<<_END
			<div class="stream">
				<a href="manager_download_csv.php?filename=orders_$res">匯出csv</a>
				<a href="manager_order_pdf.php?res=$res" target="_blank">匯出pdf</a>
			</div>
		</div>
	</div>
</body>
</html>
_END;

?>
