<?php
include 'connect.php';

session_start();

if (isset($_SESSION['u_id'])) {

	$u_id=$_SESSION['u_id'];
	$cart_items=$_SESSION['items'];
	$cart_num=$_SESSION['num'];


echo <<<_END
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Let's Ordering</title>
	<link rel="stylesheet" type="text/css" href="css/mobile.css">
</head>
<body>
	<div class="wrap">
		<div class="header">
		<a href="index.php"><img src="img/LOGO.png"></a>
		<div class="ezlogin">
_END;
			$query="SELECT * FROM user WHERE u_id='$u_id'";
			$result=mysqli_query($conn,$query);
			$row=mysqli_fetch_row($result);
			echo "安安，$row[2]!&nbsp;&nbsp;";
			echo "<a href='mobile_select_order.php'>訂單查詢</a>&nbsp;&nbsp;";
			echo "<a href='mobile_menu.php?logout=true'>登出</a>";
echo <<<_END
		</div>
		</div>
		
		<div>
			<ul class="nav1">
				<li><a href="mobile_menu.php?res=hauchang">後倉</a></li>
				<li><a href="mobile_menu.php?res=db">低逼</a></li>
				<li><a href="mobile_menu.php?res=chuanting">穿停</a></li>
				<li><a href="mobile_menu.php?res=res1">res1</a></li>
			</ul>
			<ul class="nav2">
				<li><a href="mobile_menu.php?res=res2">res2</a></li>
				<li><a href="mobile_menu.php?res=res3">res3</a></li>
				<li><a href="mobile_menu.php?res=res4">res4</a></li>
				<li><a href="mobile_menu.php?res=res5">res5</a></li>
			</ul>
		</div>
		<div class="maincontent">
_END;
	$getway="";
	if ($_SESSION['getway']=="byself") {
		$_SESSION['getway']="自取";
		$getway=$_SESSION['getway'];
	}else{
		$address=$_SESSION['getway'];
		$_SESSION['getway']="外送，地址：$address";
		$getway=$_SESSION['getway'];
	}

	$sum=0;
	$tmp_item=$_SESSION['items'];
	$tmp_num=$_SESSION['num'];
	$od_query="SELECT * FROM order_detail ORDER BY od_id DESC LIMIT 1";
	$od_result=mysqli_query($conn,$od_query);
	$od_row=mysqli_fetch_row($od_result);
	$order_id=$od_row[5]+1;
	//echo "訂單編號：00000".$order_id;

	for($i=0;$i<count($_SESSION['items']);$i++){
		$query="SELECT * FROM product WHERE pro_id='$tmp_item[$i]'";
		$result=mysqli_query($conn,$query);
		$row=mysqli_fetch_row($result); 
		$total_price=$row[2]*$tmp_num[$i];
		$sum=$sum+$total_price;
		$vi=$i+1;
		$o_res_id="";
		switch ($row[3]){
		case "hauchang":
			$o_res_id="A0000$order_id";
			break;
		case "chuanting":
			$o_res_id="B0000$order_id";
			break;
		case "db":
			$o_res_id="C0000$order_id";
			break;
		case "res1":
			$o_res_id="D0000$order_id";
			break;
		case "res2":
			$o_res_id="E0000$order_id";
			break;
		case "res3":
			$o_res_id="F0000$order_id";
			break;
		case "res4":
			$o_res_id="G0000$order_id";
			break;
		case "res5":
			$o_res_id="H0000$order_id";
			break;
		}
		//echo $o_res_id;

		//echo "<tr><td>$vi</td><td>$row[1]</td><td>$row[3]</td><td>$tmp_num[$i]</td><td>$total_price</td></tr>";
		$add_order="INSERT INTO order_detail(pro_name,res_name,o_num,o_persum,o_id,u_id,o_id_n) VALUES('$row[1]','$row[3]',$tmp_num[$i],$total_price,$order_id,'$u_id','$o_res_id')";
		//echo $add_order;
		mysqli_query($conn,$add_order);
	}

	echo "<table><tr><th>編號</th><th>名稱</th><th>餐廳</th><th>數量</th><th>價格</th></tr>";
	$query="SELECT * FROM order_detail WHERE o_id=$order_id";
	//echo $query;
	$html="";
	$result=mysqli_query($conn,$query);
	$rows=mysqli_num_rows($result);
	for($i=0;$i<$rows;$i++){
		$row=mysqli_fetch_row($result);
		$vi=$i+1;

		switch ($row[2]) {
		case 'hauchang':
			$u_res="後倉";
			break;
		case 'db':
			$u_res="低逼";
			break;
		case 'chuanting':
			$u_res="穿停";
			break;
		case 'res1':
			$u_res="res1";
			break;
		case 'res2':
			$u_res="res2";
			break;
		case 'res3':
			$u_res="res3";
			break;
		case 'res4':
			$u_res="res4";
			break;
		case 'res5':
			$u_res="res5";
			break;
		
		default:
			# code...
			break;
		}
		$html="<tr><td>$vi</td><td>$row[1]</td><td>$u_res</td><td>$row[3]</td><td>$row[4]</td></tr>";
		echo "<tr><td>$vi</td><td>$row[1]</td><td>$u_res</td><td>$row[3]</td><td>$row[4]</td></tr>";
	}
	$html=$html."<tr class='line'><td colspan='5' class='o_sum'>總金額：$sum</td></tr>";
	echo "<tr class='line'><td colspan='5' class='o_sum'>總金額：$sum</td></tr>";
	$html=$html."<tr class='line'><td colspan='5' class='o_sum'>付款方式：$getway</td><";
	echo "<tr class='line'><td colspan='5' class='o_sum'>付款方式：$getway</td><</table>";
	$html=$html."<tr><td colspan='5'>訂購者：$u_id</td></tr></table>";	

	date_default_timezone_set("Asia/Taipei");
	//取得現在時間，用字串的形式
	$tempDate = date("Y-m-d H:i:s");

	$query="SELECT DISTINCT o_id_n FROM order_detail WHERE o_id=$order_id";
	$result=mysqli_query($conn,$query);
	//echo $query;
	//$row=mysqli_fetch_row($result);
	//echo $row[0];
	while($row=mysqli_fetch_row($result)){
		$add_order="INSERT INTO orders(o_id,u_id,o_time,o_stat,o_id_n,o_getway) VALUES($order_id,'$u_id','$tempDate','未完成','$row[0]','$getway')";
		mysqli_query($conn,$add_order);
	}

	/*$query="INSERT INTO orders(o_id,u_id,o_time,o_stat) VALUES($order_id,'$u_id','$tempDate','未完成')";
	mysqli_query($conn,$query);*/

	unset($_SESSION['num']);
	unset($_SESSION['items']);

	echo"<h1>您的訂單已寄給店家，請記得取餐</h1>";

/*--------------------------mail--------------------------*/

require("/usr/share/php/libphp-phpmailer/class.phpmailer.php"); //匯入PHPMailer類別 
require("/usr/share/php/libphp-phpmailer/class.smtp.php");
echo $_SESSION['mail'];
echo $_SESSION['name'];
$mail= new PHPMailer(); //建立新物件
$mail->IsSMTP();                                // 設定使用SMTP方式寄信        
$mail->SMTPAuth = true;                         // 設定SMTP需要驗證
// $mail->SMTPDebug=2; 
$mail->SMTPSecure = "ssl";                      // Gmail的SMTP主機需要使用SSL連線   
$mail->Host="smtp.gmail.com";                 // Gmail的SMTP主機        
$mail->Port = 465;                              // Gmail的SMTP主機的port為465      
$mail->CharSet = "utf-8";                       // 設定郵件編碼   
$mail->Encoding = "base64";
$mail->WordWrap = 50;                           // 每50個字元自動斷行
      
$mail->Username = "s911297@gmail.com";     // 設定驗證帳號        
$mail->Password = "999TIMTI";              // 設定驗證密碼  
$mail->From = "s911297@gmail.com"; //設定寄件者信箱 
$mail->FromName = "system"; //設定寄件者姓名

$mail->IsHTML(true); //設定郵件內容為HTML 
$mail->Subject = "訂單"; //設定郵件標題 
$mail->Body = $html; //設定郵件內容 
$mail->AddAddress("s911297@gmail.com", "system"); //設定收件者郵件及名稱 
$mail->Send();


//--------------------------建立csv----------------------------------------------

	$query="SELECT * FROM order_detail WHERE o_id=$order_id";
	$result=mysqli_query($conn,$query);
	$rows=mysqli_num_rows($result);
	$fp_csv=fopen("csv/$order_id.csv", "w");
	$th1=mb_convert_encoding("編號","Big5","UTF-8");
	$th2=mb_convert_encoding("名稱","Big5","UTF-8");
	$th3=mb_convert_encoding("餐廳","Big5","UTF-8");
	$th4=mb_convert_encoding("數量","Big5","UTF-8");
	$th5=mb_convert_encoding("價格","Big5","UTF-8");
	$getway=mb_convert_encoding($getway,"Big5","UTF-8");
	fputs($fp_csv,"$th1,$th2,$th3,$th4,$th5\n");
	for($i=0;$i<$rows;$i++){
		$row=mysqli_fetch_row($result);
		$c1=mb_convert_encoding($row[1],"Big5","UTF-8");
		$c2=mb_convert_encoding($row[2],"Big5","UTF-8");
		$c3=mb_convert_encoding($row[3],"Big5","UTF-8");
		$c4=mb_convert_encoding($row[4],"Big5","UTF-8");
		$vi=$i+1;
		fputs($fp_csv,"$vi,$c1,$c2,$c3,$c4\n");
	}
	fputs($fp_csv,mb_convert_encoding("付款方式","Big5","UTF-8").",$getway\n");
	fputs($fp_csv,",,,".mb_convert_encoding("總金額","Big5","UTF-8").",$sum\n");
	fclose($fp_csv);



echo <<<_END

<div class="stream">
	<a href="download_csv.php?filename=$order_id">匯出csv</a>
	<a href="order_pdf.php?o_id=$order_id" target="_blank">匯出pdf</a>
</div>

_END;

}else{
echo <<<_END
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Let's Ordering</title>
	<link rel="stylesheet" type="text/css" href="css/mobile.css">
</head>
<body>
	<div class="wrap">
		<div class="header">
		<a href="index.php"><img src="img/LOGO.png"></a>
		</div>
		
		<div>
			<ul class="nav1">
				<li><a href="mobile_menu.php?res=hauchang">後倉</a></li>
				<li><a href="mobile_menu.php?res=db">低逼</a></li>
				<li><a href="mobile_menu.php?res=chuanting">穿停</a></li>
				<li><a href="mobile_menu.php?res=res1">res1</a></li>
			</ul>
			<ul class="nav2">
				<li><a href="mobile_menu.php?res=res2">res2</a></li>
				<li><a href="mobile_menu.php?res=res3">res3</a></li>
				<li><a href="mobile_menu.php?res=res4">res4</a></li>
				<li><a href="mobile_menu.php?res=res5">res5</a></li>
			</ul>
		</div>
		<div class="maincontent">
			<div class="login">
				<h1>請先登入會員</h1><br/><br/>
				<a href="mobile_login.php">點我回登入頁</a>
			</div>
		</div>
	</div>
	

</body>
</html>
_END;
}

?>
