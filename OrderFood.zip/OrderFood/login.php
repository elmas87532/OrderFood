<?php
include 'connect.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Let's Ordering</title>
	<link rel="stylesheet" type="text/css" href="css/lns.css">
</head>
<body>
	<div class="wrap">
		<div class="header">
		<a href="index.php"><img src="img/LOGO.png"></a>
		</div>
		<div class="operation">
			<h1>Login</h1>
		</div>
		<div class="sidebar">
			<ul class="sidebars">
				<li>商店總覽</li>
				<li><a href="menu.php?res=hauchang">後倉</a></li>
				<li><a href="menu.php?res=db">低逼</a></li>
				<li><a href="menu.php?res=chuanting">穿停</a></li>
				<li><a href="menu.php?res=res1">res1</a></li>
				<li><a href="menu.php?res=res2">res2</a></li>
				<li><a href="menu.php?res=res3">res3</a></li>
				<li><a href="menu.php?res=res4">res4</a></li>
				<li><a href="menu.php?res=res5">res5</a></li>
			</ul>
		</div>
		<div class="maincontent">
			<div class="login">
				<h1>會員登入</h1>
				<form action="menu.php" method="post">
					帳號：<input type="text" name="u_id" /><br/>
					密碼：<input type="password" name="u_pw" /><br/><br/>
					<input type="hidden" name="logined" value="true" />
				<input type="submit" value="登入"><br/><br/>
				</form>
				<a class="login" href="sign.php">註冊</a>
			</div>
			
		</div>
	</div>
	

</body>
</html>