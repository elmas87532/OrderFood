<?php
/*$conn=mysqli_connect("localhost","foood","abc123","order_system");
if(!$conn)die("Unable to connect to MySQL: ".mysql_error());*/

include("connect.php");

session_start();

if (isset($_GET['res'])) {
	$_SESSION['res']=$_GET['res'];
}


$res=$_SESSION['res'];


if(isset($_GET['logout'])){
	unset($_SESSION['res']);
}

$o_id_n="";
if(isset($_GET['o_id_n'])){
	$o_id_n=$_GET['o_id_n'];
}

echo <<<_END
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Let's Ordering</title>
	<link rel="stylesheet" type="text/css" href="css/manager.css">
</head>
<body>
	<div class="wrap">
		<div class="header">
		<a href="index.php"><img src="img/LOGO.png"></a>
		<div class="ezlogin">
_END;
			$query="SELECT * FROM manager WHERE res_name='$res'";
			$result=mysqli_query($conn,$query);
			$row=mysqli_fetch_row($result);
			echo "歡迎，$row[2]!&nbsp;&nbsp;";
			echo "<a href='menu.php?logout=true'>登出</a>";
echo <<<_END
		</div>
		</div>
		<div class="operation">
			<h1>Menu</h1>
		</div>
		<div class="sidebar">
			<ul class="sidebars">
				<li>操作項目</li>
				<li><a href="manager_menu.php">菜單管理</a></li>
				<li><a href="manager_orders.php">訂單管理</a></li>
			</ul>
		</div>
		<div class="maincontent">
_END;

echo "訂單編號：$o_id_n";
echo "<div class='order'><table class='order'><tr class='titletr'><td>商品</td><td>數量</td><td>價格</td></tr>";

$query="SELECT * FROM order_detail WHERE o_id_n='$o_id_n'";
$result=mysqli_query($conn,$query);
$sum=0;
while ($row=mysqli_fetch_row($result)) {
	echo "<tr><td>$row[1]</td><td>$row[3]</td><td class='righttd'>$row[4] 元</td></tr>";
	$sum=$sum+$row[4];
}
echo "<tr><td colspan='3' class='righttd'>總金額：$sum"." 元</td></tr></table>";

echo "<div class='complete'><a href='manager_orders.php?stat=complete&o_id_n=$o_id_n'>取餐完成</a></div></div>";

echo <<<_END
		</div>
	</div>
</body>
</html>
_END;
?>
