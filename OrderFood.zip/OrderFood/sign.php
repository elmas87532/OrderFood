<?php
include 'connect.php';

if (isset($_GET['none'])) {
	$none=$_GET['none'];
	switch ($none) {
		case 'id':
			echo "<script>alert('帳號不可空白！')</script>";
			break;
		case 'pw':
			echo "<script>alert('密碼不可空白！')</script>";
			break;
		case 'name':
			echo "<script>alert('姓名不可空白！')</script>";
			break;
		
		default:
			# code...
			break;
	}
}
if (isset($_GET['idyet'])) {
	echo "<script>alert('此帳號已存在')</script>";
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Let's Ordering</title>
	<link rel="stylesheet" type="text/css" href="css/lns.css">
</head>
<body>
	<div class="wrap">
		<div class="header">
		<a href="index.php"><img src="img/LOGO.png"></a>
		</div>
		<div class="operation">
			<h1>Login</h1>
		</div>
		<div class="sidebar">
			<ul class="sidebars">
				<li>商店總覽</li>
				<li><a href="menu.php?res=hauchang">後倉</a></li>
				<li><a href="menu.php?res=db">低逼</a></li>
				<li><a href="menu.php?res=chuanting">穿停</a></li>
				<li><a href="menu.php?res=res1">res1</a></li>
				<li><a href="menu.php?res=res2">res2</a></li>
				<li><a href="menu.php?res=res3">res3</a></li>
				<li><a href="menu.php?res=res4">res4</a></li>
				<li><a href="menu.php?res=res5">res5</a></li>
			</ul>
		</div>
		<div class="maincontent">
			<div class="sign">
				<h1>註冊會員</h1>
				<form action="signsuccess.php" method="post">
					*帳號：<input type="text" name="u_id" size="24" maxlength="16" onkeyup="value=value.replace(/[\W]/g,'') " onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"><br/>
					(限16英文數字)<br/>
					*密碼：<input type="password" name="u_pw" size="24" maxlength="16" onkeyup="value=value.replace(/[\W]/g,'') " onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"><br/>
					(限16英文數字)<br/>
					*姓名：<input type="text" name="u_name" size="24" /><br/>
					性別：<input type="radio" name="u_gender" value="male" />男&nbsp;
					<input type="radio" name="u_gender" value="female" />女<br/>
					生日：<input type="date" name="u_birth" size="24" /><br/>
					市話：<input type="text" name="u_phone" size="24" maxlength="9" onkeyup="value=value.replace(/[^\d]/g,'') " onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"><br/>
					手機：<input type="text" name="u_cphone" size="24" maxlength="10" onkeyup="value=value.replace(/[^\d]/g,'') " onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"><br/>
					地址：<br/>
					<input type="text" name="u_address" size="40" /><br/><br/>
					<input type="hidden" name="have_sign" value="true" /><br/><br/>
					<input type="submit" value="送出">
				</form>
			</div>
			
		</div>
	</div>
	

</body>
</html>