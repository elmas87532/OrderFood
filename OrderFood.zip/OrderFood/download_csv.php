<?php
$filename=$_GET['filename'];
$filepath="csv/$filename.csv";
echo $filename;
header('Content-type:application/force-download'); //告訴瀏覽器 為下載 
header('Content-Transfer-Encoding: Binary'); //編碼方式
header('Content-Disposition:attachment;filename=order_detail.csv'); //輸出的檔名
readfile($filepath);
?>
