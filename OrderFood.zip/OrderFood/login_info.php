<?php
	$db_hostname='localhost';
	$db_database='order_system';
	$db_username='root';
	$db_password='';
?>