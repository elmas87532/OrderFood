<?php
echo "test";
$fp=fopen("/var/www/html/csv/tmp.csv","w");
fwrite($fp,"1\t3\t4\t");
fflush($fp);
fclose($fp);
?>
